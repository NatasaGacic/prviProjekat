$(document).ready(function () {
    $("#forma").hide();
    $("#prikazi").on('click', function () {
        $("#forma").show();
    });
    $("#noviRed").on('click', function () {
        $("#forma").hide();
    });
    $(".remove").on('click', function () {
        $(this).closest("tr").remove();
    });
    $("#noviRed").click(function(){
        var ime = $("#ime").val();
        var prezime = $("#prezime").val();
        var email = $("#email").val();
        var noviRed = "<tr><td>" + ime + "</td><td>" + prezime + "</td><td>" + email + "</td><td class='remove'><i class='fa fa-times' aria-hidden='true'></i></td></tr>";
        $("#podaciTabela tbody").append(noviRed);
        $("#ime, #prezime, #email").val('');
    });
    $("#podaciTabela tbody").on("click", "tr", function() {
        var trenutniRed = $(this);
        function azurirajRed(indeks, ime, prezime, email) {
            trenutniRed.find("td:eq(0)").text(ime);
            trenutniRed.find("td:eq(1)").text(prezime);
            trenutniRed.find("td:eq(2)").text(email);
        }
        var ime = prompt("Unesite novo ime:", trenutniRed.find("td:eq(0)").text()) || '';
        var prezime = prompt("Unesite novo prezime:", trenutniRed.find("td:eq(1)").text()) || '';
        var email = prompt("Unesite novi email:", trenutniRed.find("td:eq(2)").text()) || '';
    
        azurirajRed(trenutniRed.index(), ime, prezime, email);
    });
});






