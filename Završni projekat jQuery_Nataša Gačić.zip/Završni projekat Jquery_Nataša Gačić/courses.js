var allData = [];

$(document).ready(function () {
    var editTableRow;
    getData();
    $("#container-fluid-reservation-table").hide();

    $(document).on('click', '.btn-details', function () {
        var course = $(this).closest('tr').find('td:eq(0)').text().trim();
        var price = $(this).closest('tr').find('td:eq(3)').text().trim();
        var imageSrc = $(this).closest('tr').find('td[data-image-src]').data('image-src');
        var description = $(this).closest('tr').find('td[data-description]').data('description');

        console.log(description);

        $('#exampleModalLabel').text(course.toUpperCase());
        $('.modal-body img').attr('src', imageSrc);
        $('.modal-body p').text(description);
        $('.modal-body h6').text(price);
        $('#exampleModal').modal('show');
    });

    $(document).on("click", ".btn-reservation", function () {
        var course = $(this).closest('tr').find('td:eq(0)').text().trim();
        var price = $(this).closest('tr').find('td:eq(3)').text().trim();

        $('#course').val(course);
        $('#price').val(price);
        $("#makeReservationModal").modal("show");
    });

    $(document).on('click', '.btn-view-all', function () {
        $("#container-fluid-courses-table").hide();
        $("#container-fluid-reservation-table").show();
    });

    $(document).on('click', '.btn-back-course', function () {
        $("#container-fluid-reservation-table").hide();
        $("#container-fluid-courses-table").show();
    });

    $(document).on('click', '.btn-change-reservation', function () {
        var $row = $(this).closest('tr');
        var name = $row.find('.edit-name').text().trim();
        var surname = $row.find('.edit-surname').text().trim();
        var email = $row.find('.edit-email').text().trim();
        var course = $row.find('.edit-course').text().trim();
        var price = $row.find('.edit-price').text().trim();
        var note = $row.find('.edit-note').text().trim();

        editTableRow = $row;

        $('#edit-name-data').val(name);
        $('#edit-surname-data').val(surname);
        $('#edit-email-data').val(email);
        $('#edit-course-data').val(course);
        $('#edit-price-data').val(price);
        $('#edit-note-data').val(note);

        $("#editReservationModal").modal("show");
    });

    $(document).on('click', '.btn-delete-reservation', function () {
        var deleteRow = $(this).closest('tr');
        deleteRow.remove();
        updateSum();
    })

    $(document).on('click', '.js-edit-reservation', function () {
        var course = $('#edit-course-data').val().trim();
        var price = $('#edit-price-data').val().trim();
        var name = $('#edit-name-data').val().trim();
        var surname = $('#edit-surname-data').val().trim();
        var email = $('#edit-email-data').val().trim();
        var note = $('#edit-note-data').val().trim();

        var $row = editTableRow;
        $row.find('.edit-name').text(name);
        $row.find('.edit-surname').text(surname);
        $row.find('.edit-email').text(email);
        $row.find('.edit-course').text(course);
        $row.find('.edit-price').text(price);
        $row.find('.edit-note').text(note);

        $('#editReservationModal').modal('hide');
    });

    $("#forma").validate({
        rules: {
            name: {
                required: true,
            },
            surname: {
                required: true,
            },
            email: "required",
            note: {
                required: true,
                minlength: 10
            }
        },
        messages: {
            name: {
                required: "Unesite vase ime",
            },
            surname: {
                required: "Unesite vase prezime",
            },
            email: "Unesite validan email",
            note: {
                required: "Komentar je obavezan",
                minlength: "Mora imati minimum 10 karaktera"
            }
        }
    });

})

function getData() {
    var getRequest = $.ajax({
        type: "GET",
        url: "http://localhost:3000/courses"
    });
    getRequest.done(function (podaci) {
        allData = podaci;
        console.log(allData);
        fillTable(podaci);
        $("#courses-table").dataTable();
    });
}

function fillTable(data) {
    $("#courses-table-body").empty();
    $.each(data, function (i, podatak) {
        $("#courses-table-body").append(`
            <tr>
                <td data-image-src="${podatak.image}" data-description="${podatak.text}"> ${podatak.course} </td>
                <td> ${podatak.startingDate} </td>
                <td> ${podatak.duration} </td>
                <td> ${podatak.price} </td>
                <td> <button class="btn btn-outline-success btn-details" id="edit_${podatak.id}">View details</button> </td>
                <td> <button class="btn btn-outline-success btn-reservation" id="edit_${podatak.id}">Make reservation</button> </td>
            </tr>
        `)
    })
}

function saveChanges() {
    var course = $('#course').val().trim();
    var price = $('#price').val().trim();
    var name = $('#name').val().trim();
    var surname = $('#surname').val().trim();
    var email = $('#email').val().trim();
    var note = $('#note').val().trim();

    var newRow = $('<tr>');
    newRow.append('<td class="edit-name">' + name + '</td>');
    newRow.append('<td class="edit-surname">' + surname + '</td>');
    newRow.append('<td class="edit-email">' + email + '</td>');
    newRow.append('<td class="edit-course">' + course + '</td>');
    newRow.append('<td class="edit-price">' + price + '</td>');
    newRow.append('<td class="edit-note">' + note + '</td>');
    newRow.append('<td><button class="btn btn-outline-success btn-change-reservation" id="edit_new">Change Reservation</button></td>');
    newRow.append('<td><button class="btn btn-outline-success btn-delete-reservation" id="edit_new">Delete Reservation</button></td>');

    $('#reservation-table-body').append(newRow);

    $('#makeReservationModal').modal('hide');

    clearModalInputs();

    updateSum();
}
function clearModalInputs() {
    document.getElementById("name").value = "";
    document.getElementById("surname").value = "";
    document.getElementById("email").value = "";
    document.getElementById("note").value = "";
}

function updateSum() {
    var sum = 0;
    $('#reservation-table-body tr').each(function () {
        var priceText = $(this).find('.edit-price').text().trim();

        var price = parseFloat(priceText);
        if (!isNaN(price)) {
            sum += price;
        }
    });

    $('#totalSum').text('TOTAL SUM: ' + sum + '$');
}





