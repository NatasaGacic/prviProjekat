var div = document.getElementById("color");

function getRandomColor() {
    var letters = '0123456789ABCDEF';
    var color = '#';
    for (var i = 0; i < 6; i++ ) {
        color += letters[Math.floor(Math.random() * 16)];}
    return color;
}

function changeColor(){
  div.style.backgroundColor= getRandomColor();
}

setInterval(changeColor,1000);

function clickMe(){
    alert("Welcome!")
}

function changeText() {
    document.getElementById("text").innerHTML = 'Text has changed!';
    var paragraf = document.getElementById("text");
    paragraf.style.backgroundColor = "white";
    paragraf.style.fontSize = "30px";
}

function hover(img) {
 img.src = "img/do.jpg"
}

function gender() {
    var r1 = document.getElementById("male");
    var r2 = document.getElementById("female");
    var message = document.getElementById("span1");
    if (r1.checked) {
        message.innerHTML = "Selected Gender: Male";
    }
    else if (r2.checked) {
        message.innerHTML = "Selected Gender: Female";
    }
    else  {
        message.innerHTML = "You have not selected any option";
    }
}

function showInput() {
    let vrednost1 = document.getElementById("name").value;
    let vrednost2 = document.getElementById("lastname").value;
    let vrednost3 = document.getElementById("animal").value;
    var message = document.getElementById("show");
    message.innerHTML = vrednost1 + "</br>" + vrednost2 + "</br>" + vrednost3 + "</br>";
}