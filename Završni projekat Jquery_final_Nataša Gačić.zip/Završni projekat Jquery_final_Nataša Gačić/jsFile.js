var promena = "";

function openFirstBlock() {
    document.getElementById('uvod').style.display = "none";
    document.getElementById('first-block').style.display = "block";
    setQuestion(1, "first");
}

function openSecondBlock() {
    var inputText = document.getElementById("input-text").value;
    if (inputText) {
        document.getElementById('first-block').style.display = "none";
        document.getElementById('second-block').style.display = "block";
        setQuestion(2, "second");
        promena = inputText;
    } else {
        alert('Name must be filled out');
    }}

function openThirdBlock() {
    document.getElementById('second-block').style.display = "none";
    document.getElementById('third-block').style.display = "block";
    setQuestion(3, "third");
}

function openOther() {
    document.getElementById('invisible-input').style.display = "block";
}

function openFourthBlock() {
    document.getElementById('third-block').style.display = "none";
    document.getElementById('fourth-block').style.display = "block";
    setQuestion(4, "fourth");
}

function openFifthBlock() {
    document.getElementById('fourth-block').style.display = "none";
    document.getElementById('fifth-block').style.display = "block";
    setQuestion(5, "fifth");
}

function submitSurvey() {
    var sliderValue = document.getElementById('customRange1').value;
    var messageContainer = document.getElementById('message-container');
    messageContainer.innerHTML = '';
    var message = '';
    var thirdMessage = '';
    var emojiClassName = '';
    switch (sliderValue) {
      case '1': 
        message = "Hi " + promena;
        thirdMessage = "We appreciate your opinion. Oooops, sorry to disappoint you."
        emojiClassName = "fa fa-frown-o";
        break;
      case '2':
        message = "Hi " + promena;
        thirdMessage = "We appreciate your opinion. We hope it will be better next time!"
        emojiClassName = "fa fa-frown-o";
        break;
      case '3':
        message = "Hi " + promena;
        thirdMessage = "We appreciate your opinion. Golden middle!"
        emojiClassName = "fa fa-meh-o";
        break;
      case '4':
        message = "Hi " + promena;
        thirdMessage = "We appreciate your opinion. Thanks for the very good rating!"
        emojiClassName = "fa fa-smile-o";
        break;
      case '5':
        message = "Hi " + promena;
        thirdMessage = "We appreciate your opinion. Perfect! We are glad to meet your requirments!"
        emojiClassName = "fa fa-smile-o";
        break;
    }
  
    var messageElement = document.createElement('h1');
    messageElement.textContent = message;
    messageContainer.appendChild(messageElement);

    var messageHeading = document.createElement('h1');
    messageHeading.textContent = "Thank you for your time!";
    messageContainer.appendChild(messageHeading);

    var messageText = document.createElement('p');
    messageText.textContent = thirdMessage;
    messageContainer.appendChild(messageText);

    var messageEmoji = document.createElement('i');
    messageEmoji.className = emojiClassName;
    messageContainer.appendChild(messageEmoji);

    document.getElementById('fifth-block').style.display = "none";
  }

  function setQuestion(questionNumber, questionPrefix) {
    var questionText = "Question " + questionNumber + " of 5";
    var questionClassName = questionPrefix + "-question";
    var questionParagraph = document.querySelector('#' + questionClassName);
    questionParagraph.innerHTML = questionText;
}