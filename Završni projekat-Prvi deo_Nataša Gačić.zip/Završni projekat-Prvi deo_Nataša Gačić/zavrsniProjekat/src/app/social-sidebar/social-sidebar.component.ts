import { Component } from '@angular/core';

@Component({
  selector: 'app-social-sidebar',
  templateUrl: './social-sidebar.component.html',
  styleUrl: './social-sidebar.component.css'
})
export class SocialSidebarComponent {

}
