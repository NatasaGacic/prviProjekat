function openWindow() {
    var numberInput = prompt("Unesite broj od 1 do 5");
    if (numberInput != null) {
        var parseInput = parseInt(numberInput);
        if (isNaN(parseInput)) {
            document.write("Niste uneli broj!")
        }
        else {
            if (parseInput < 1 || parseInput > 5) {
                document.write("Unesen broj mora biti izmedju 1 i 5!");
            }
            else if (parseInput == 1) {
                document.write("Nikad nemoj odustati, jer uvek postoji vreme i mesto kada ce se plima promeniti.");
            }
            else if (parseInput == 2) {
                document.write("Kreativan covek motivisan je zeljom da postigne, a ne zeljom da pobedi druge.");
            }
            else if (parseInput == 3) {
                document.write("Neka ti udica bude uvek bacena. U jezeru u kojem najmanje ocekujes, pojavice se riba.");
            }
            else if (parseInput == 4) {
                document.write(" Preko noci postaje slavan samo onaj ko je danima neumorno radio.");
            }
            else {
                document.write("Velika je nesreca kad covek ne zna sta hoce, a prava katastrofa kad ne zna sta moze.");
            }   
        }
    }
}