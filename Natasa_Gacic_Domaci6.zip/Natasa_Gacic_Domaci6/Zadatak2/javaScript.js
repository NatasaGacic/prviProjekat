function openWindow(option) {
    var numberInput = prompt("Insert number between 1 and 999");
    if (numberInput != null) {
        var parseInput = parseFloat(numberInput);
        if (isNaN(parseInput)) {
            alert("This is not a number")
        }
        else {
            if (parseInput < 1 || parseInput > 999) {
                alert("Number must be between 1 and 999");
            }
            else {
                switch (option) {
                    case 'button1':
                        alert(Math.sqrt(numberInput))
                        break
                    case 'button2':
                        alert(Math.sin(numberInput))
                        break
                    case 'button3':
                        alert(Math.cos(numberInput))
                        break
                    case 'button4':
                        alert(Math.round(numberInput))
                        break
                }
            }
            
        }
    }
}